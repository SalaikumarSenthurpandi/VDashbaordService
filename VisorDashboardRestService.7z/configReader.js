const fs = require('fs');
const process = require('process');
const path = process.cwd();
const configuration = fs.readFileSync(path + '/config.json');
const configString = configuration.toString();
const jsonData = JSON.parse(configString);

const getDefaults = () => {
    return jsonData.defaults;
}

const getDatabase = () => {
    return jsonData.database;
}

const getAwsConfig = () => {
    return jsonData.aws_athena;
}

module.exports = {
    getDatabase, getDefaults, getAwsConfig
}