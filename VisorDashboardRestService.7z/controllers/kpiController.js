const sql = require('mssql');
const errors = require('../errors/errors.js');
const connection = require('../connection')();
//const generic = require('../Generic');
//const S3 = require('../S3');
const dbConfig= configReader.getDatabase();

const Pool = require('pg').Pool;

const pool = new Pool({
    user: dbConfig.user,
    host: dbConfig.server,
    database: dbConfig.database,
    password: dbConfig.password,
    port: dbConfig.customport,
    timezone: 'Z'
})

const GetSonardyneSignals = (req, res, next) => {
    const id = parseInt(req.params.id)
    console.log("GetSonardyneSiganals" + id);

    try{

        let sSQL = "SELECT * FROM  sonardyne_signals_master";

        pool.query(sSQL, (error, results) => {
            if(error) {
                throw error
            }

            res.status(200).json(results.rows)
        })
    } catch (error) {
        next(error);
    }
};

const GetRawKPIDataforSonardynePOC = (req, res, next) => {
    const signalNames = req.params.signalname;
    const deviceNames = req.params.devicename;
    const serialno = req.params.serialno;

    let signalarr = signalNames.split(',');
    console.log("signalarr" + signalarr);

    try{

        let dSQL = '';

        for (let i=0; i < signalarr.length; i++) {

            let assetname = signalarr[i].split('.', 1)[0];

            switch (assetname) {
                case value:
                    //Salai.. Write the sql query to fetch kpi data from db.
                    break;
            
                default:
                    break;
            }
        }

        pool.query(dSQL, (error, results) => {
            if(error) {
                next(error);
            } else {
                res.status(200).json(results.rows)
            }

            
        })
    } catch (error) {
        next(error);
    }
};

module.exports = {
    GetSonardyneSignals,
    GetRawKPIDataforSonardynePOC
}