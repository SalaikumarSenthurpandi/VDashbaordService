const express = require('express');
const app = express();
const morgan = require('morgan');
const sql = require('mssql');
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(morgan('common'));

//Using KPIRoutes only for Sonardyne. 
const kpiRoutes = require('./routes/kpi_routes.js');
app.use(kpiRoutes);

app.get("/", (req, res, next) => {
    throw new Error("Something went wrong!");
});

app.use("/", (req, res, next) => {
    const error = new Error("Not found");
    error.status = 404;
    next(error);
});

//error handler middleware
app.use((error, req, res, next) => {
    res.status(error.status || 500).send({
        error: {
            status: error.status || 500,
            message: error.message || 'Internal Server Error',
        },
    });
});

module.exports = app;


