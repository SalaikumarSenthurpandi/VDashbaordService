const http = require('http');
var portfinder = require('portfinder');
const app = require('./app');
//const generic = require('./Generic');
const configReader = require('./configReader');
const defaults = configReader.getDefaults();

const port = defaults.port;
const server = http.createServer(app);

portfinder.basePort = port;
portfinder.highestPort = port;

portfinder.getPortPromise()
    .then((port) => {
        server.listen(port, ()=> {
            generic.Log("Server listening on " + port, 'info');
        })
    })
    .catch((err) => {
        generic.Log("Failure!! Unable to start server on " + port + ". " + err, 'err');
        process.exit();
    });