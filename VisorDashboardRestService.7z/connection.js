const sql = require('mssql');
const configReader = require('./configReader');
const dbConfig= configReader.getDatabase();

const connect =  (enableMultipleQuery) => {
    try {
        const multipleStatements = enableMultipleQuery ? enableMultipleQuery : false;
        const config = {
            "user": dbConfig.user,
            "password": dbConfig.password,
            "server": dbConfig.server,
            "database": dbConfig.database,
            "port": dbConfig.customport,
            "multipleStatements": multipleStatements,
            "options.enableArithAbort": true,
            "options.encrypt": false
        }
        const conn = new sql.ConnectionPool(config);
        return conn;
    } catch (error) {
        console.log('Database connection Failed. Bad Config: ', error)
    }
};

module.exports = connect;