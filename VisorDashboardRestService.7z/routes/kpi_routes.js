const express = require('express');
const router = express.Router();
const kpiController = require('../controllers/kpiController');

router.get("/GetSonardyneSignals/:serialno", (req, res, next) => {
    console.log('GetSonardyneSignals - serialNo:' + req.params.serialno);
    res.locals.outputType = "JSON";
    kpiController.GetSonardyneSignals(req, res, next);
});

router.get("/GetRawKPIDataforSonardynePOC/:signalname/devicename/:serialno", (req, res, next) => {
    console.log('GetRawKPIDataforSonardynePOC - signalname:' + req.params.signalname + 'devicename:' + req.params.devicename + 'serialNo:' + req.params.serialno);
    res.locals.outputType = "JSON";
    kpiController.GetRawKPIDataforSonardynePOC(req, res, next);
});

module.exports = router;